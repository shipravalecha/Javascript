// --- Directions
// Check to see if two provided strings are anagrams of eachother.
// One string is an anagram of another if it uses the same characters
// in the same quantity. Only consider characters, not spaces
// or punctuation.  Consider capital letters to be the same as lower case
// --- Examples
//   anagrams('rail safety', 'fairy tales') --> True
//   anagrams('RAIL! SAFETY!', 'fairy tales') --> True
//   anagrams('Hi there', 'Bye there') --> False

function anagrams(stringA, stringB) {
/** 1st approach	
	var object1 = {};
	var object2 = {};
	var value;
	
	for(var char of stringA.replace(/[^\w\s]/gi, "").toLowerCase()){
		if(object1[char]){
			object1[char]++;
		}
		else{
			object1[char] = 1;
		}
	}
	
	for(var char of stringB.replace(/[^\w\s]/gi, "").toLowerCase()){
		if(object2[char]){
			object2[char]++;
		}
		else{
			object2[char] = 1;
		}
	}
	
	// another way to know the length of object:
	// Objects.keys(object1).length
	for(var char in object1){
		// for(var char in object2){ 
			if(object1[char] === object2[char] && stringA.length === stringB.length){
				value = true;
			}
			else{
				value = false;
			}
		
	}
	
	return value;
	
**/ 

// 2nd approach

var value;
stringA.replace(/[^\w]/gi,"").toLowerCase();
stringB.replace(/[^\w]/gi,"").toLowerCase();

var arr1 = stringA.split('');
var arr2 = stringB.split('');


arr1.sort();
arr2.sort();

var str1 = arr1.join('');
var str2 = arr2.join('');

if(str1 === str2){
	value = true;
}
else{
	value = false;
}

return value;




}

module.exports = anagrams;
