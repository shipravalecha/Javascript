// --- Directions
// Write a function that accepts a string.  The function should
// capitalize the first letter of each word in the string then
// return the capitalized string.
// --- Examples
//   capitalize('a short sentence') --> 'A Short Sentence'
//   capitalize('a lazy fox') --> 'A Lazy Fox'
//   capitalize('look, it is working!') --> 'Look, It Is Working!'

function capitalize(str) {

/** 1st approach
var words = [];
var capitalword = [];
words = str.split(" ");
var str2;

for(i = 0; i < words.length; i++){
	var lenn = words[i].length;
    capitalword.push(words[i][0].toUpperCase() + words[i].slice(1,lenn));
	str2 = capitalword.join(" ");
}

return str2;
 **/
 
 
// second approach
 
 
 var str1 = str[0].toUpperCase();

 for(var i = 1; i < str.length; i++){
	 
	 if(str[i-1] === ' '){
		 str1 += str[i].toUpperCase();
	 }
	 else{
		 str1 += str[i];
	 }
	 
 }
 
 return str1;
 
}


module.exports = capitalize;
