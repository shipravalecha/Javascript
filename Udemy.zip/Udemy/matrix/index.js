// --- Directions
// Write a function that accepts an integer N
// and returns a NxN spiral matrix.
// --- Examples
//   matrix(2)
//     [[1, 2],
//     [4, 3]]
//   matrix(3)
//     [[1, 2, 3],
//     [8, 9, 4],
//     [7, 6, 5]]
//  matrix(4)
//     [[1,   2,  3, 4],
//     [12, 13, 14, 5],
//     [11, 16, 15, 6],
//     [10,  9,  8, 7]]

function matrix(n) {
	
    var results = [];
	for(var i = 0; i < n;i++){
		results.push([]);
	}
	var counter = 1;
	var startcol = 0;
	var endcol = n -1;
	var startrow = 0;
	var endrow = n -1;
	while(startrow <= endrow && startcol <= endcol){
	// 1st row
	for(var i = startcol; i <= endcol; i++){
		results[startrow][i] = counter;
		counter++;
	}
	startrow++;
	// last col
	for(var i = startrow; i <= endrow; i++){
		results[i][endcol] = counter;
		counter++;
	}
	endcol--;
	//last row
	for(var i = endcol; i >= startcol; i--){
		results[endrow][i] = counter;
		counter++;
	}
	endrow--;
	//middle row
	for(var i = endrow; i >= startrow; i--){
		results[i][startcol] = counter;
		counter++;
	}
	startcol++;	
	
	
	
	}
	return results;
}

module.exports = matrix;
