// --- Directions
// Given a string, return a new string with the reversed
// order of characters
// --- Examples
//   reverse('apple') === 'leppa'
//   reverse('hello') === 'olleh'
//   reverse('Greetings!') === '!sgniteerG'

/*  first approach
 function reverse(str) {
	
	return str.split("").reverse().join("");
	}
*/


/* second approach
 
function reverse(str)
{

var newstring = "";

for(i = str.length-1; i >= 0; i--){

newstring = newstring + str[i];

}

return newstring;
 
}

*/


/* second new approach

function reverse(str)
{

var newstring = "";

for(var character of str){

newstring =  character + newstring;

}

return newstring;
 
}



*/


function reverse(str)
{
return str.split("").reduce((newstring, character) => character + newstring, '');
 
}

module.exports = reverse;