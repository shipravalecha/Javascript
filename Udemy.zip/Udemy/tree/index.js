// --- Directions
// 1) Create a node class.  The constructor
// should accept an argument that gets assigned
// to the data property and initialize an
// empty array for storing children. The node
// class should have methods 'add' and 'remove'.
// 2) Create a tree class. The tree constructor
// should initialize a 'root' property to null.
// 3) Implement 'traverseBF' and 'traverseDF'
// on the tree class.  Each method should accept a
// function that gets called with each element in the tree

class Node {
	constructor(data, children){
		this.data = data;
		this.children = [];
	}
	add(data){
		var node = new Node(data);
		this.children.push(node);
	}
	
	remove(data){
		this.children = this.children.filter( node =>	{
		
        return node.data !== data;
		
		});
	}
}

class Tree {
	constructor(root){
		this.root = null;
	}
	
	traverseBF(fn){
		
	var array1 = [];
    array1.push(this.root);
	
    while(array1.length){
	var node = array1.shift();
	array1.push(...node.children);
	fn(node);
    }
   
}

	traverseDF(fn){
	var array1 = [];
    array1.push(this.root);
	
	while(array1.length){
	var node = array1.shift();
	array1.unshift(...node.children);
	fn(node);
    }
	
	}

}

module.exports = { Tree, Node };
