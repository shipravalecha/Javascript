// --- Directions
// Write a function that returns the number of vowels
// used in a string.  Vowels are the characters 'a', 'e'
// 'i', 'o', and 'u'.
// --- Examples
//   vowels('Hi There!') --> 3
//   vowels('Why do you ask?') --> 4
//   vowels('Why?') --> 0

function vowels(str) {
	// reg ex returns array if match else no
	var matches = str.match(/[aeiou]/gi);
    return matches ? matches.length : 0
}

module.exports = vowels;


// 1st approach
/*
function vowels(str) {
	
var str1 =	str.toLowerCase();
	var count = 0;
	var chars = {};
	for(var character of str1){
		if(chars[character]){
			chars[character]++;
		}
		else{
			chars[character] = 1;
		}
		
	}

	count = chars['a'] + chars['e']+ chars['i']+ chars['o']+ chars['u'];
	
	if(!chars['a'] && !chars['e']&& !chars['i']&& !chars['o']&&!chars['u']){
		count = 0;
	}
	
	
	
	return count;
}

module.exports = vowels;
*/


// 2nd approach
/*
function vowels(str) {
	
var str1 =	str.toLowerCase();
	var count = 0;
	var checkers = ['a', 'e', 'i', 'o', 'u']
	
	for(var character of str1){
		
		if(checkers.includes(character)){
			count++;
		}
	}
	return count;
}

module.exports = vowels;

*/


// 3rd approach
/*
function vowels(str) {
	
var str1 =	str.toLowerCase();
	var count = 0;
	var checkers = 'aeiou';
	 
	 for(var character of str1){
		 if(checkers.includes(character)){
			 count++;
		 }
	 }

	return count;
}

*/